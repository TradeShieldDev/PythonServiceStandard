
class LoggingSettings():    
    file_name:str = None
    path:str = None
    level:str = None
    max_file_size_in_mb:int = None
    max_retention_days:int = None